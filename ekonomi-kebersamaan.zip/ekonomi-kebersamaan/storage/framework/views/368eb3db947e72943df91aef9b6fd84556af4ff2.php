<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('plugins/bootstrap-datepicker/css/bootstrap-datepicker.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Data Anggota Kelompok Peternak</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
    </div>
    <?php if(session()->has('flash_notification.message')): ?>
        <div class="alert alert-<?php echo e(session()->get('flash_notification.level')); ?>">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo session()->get('flash_notification.message'); ?>

        </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('dataternak.store')); ?>" role="form">
        <?php echo csrf_field(); ?>
        <label style="color:black">NIK</label>
        <input type="text" class="form-control form-control-user" id="nik" name="nik" aria-describedby="emailHelp"
               placeholder="">
        <label style="color:black">Nama Peternak</label>
        <input type="text" class="form-control form-control-user" id="nama" name="nama" aria-describedby="emailHelp"
               placeholder="" disabled>
        <label style="color:black">Alamat</label>
        <input type="text" class="form-control form-control-user" id="alamat" name="alamat" aria-describedby="emailHelp"
               placeholder="" disabled>
        <label style="color:black">Desa</label>
        <input type="text" class="form-control form-control-user" id="desa" name="desa" aria-describedby="emailHelp"
               placeholder="" disabled>
        <label style="color:black">Kecamatan</label>
        <input type="text" class="form-control form-control-user" id="kec" name="kec" aria-describedby="emailHelp"
               placeholder="" disabled>
        <label style="color:black">Nama Kelompok</label>
        <select class="form-control show-tick" name="idkelompok">
            <option value="">-- Please select --</option>
            <?php $__currentLoopData = $kelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($values->idkelompokternak); ?>"><?php echo e($values->namakelompokternak); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label style="color:black">Jabatan</label>
        <select class="form-control show-tick" name="jabatan">
            <option value="anggota">Anggota</option>
            <option value="ketua">Ketua</option>
            <option value="sekretaris">Sekretaris</option>
            <option value="bendahara">Bendahara</option>
        </select>
        <label style="color:black">Tanggal Bergabung</label>
        <input type="text" class="form-control datepicker" id="datepicker" name="tgl"
               aria-describedby="emailHelp" required>

        <br>
        <button type="submit" class="btn-sm btn-primary shadow-sm">
            SIMPAN
        </button>

    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('plugins/bootstrap-datepicker/js/bootstrap-datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/dist/js/standalone/selectize.js')); ?>"></script>

    <script>
        $(function () {
            $('.datepicker').datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
            });
        });
        $('#nik').change(function () {
            var kode = $("#nik").val();

            $.ajax({
                url: "<?php echo e(url('/ceknik')); ?>/" + kode,
                type: 'GET',
                datatype: 'json',
                success: function (x) {
                    $.each(x, function (index, z) {
                        $('#nama').val(z.nama);
                        $('#alamat').val(z.alamat);
                        $('#desa').val(z.namadesa);
                        $('#kec').val(z.kecamatan);
                    });
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.masterdashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/acek/Documents/MyApps/ekonomi-kebersamaan/resources/views/peternakan/keanggotaanpeternak.blade.php ENDPATH**/ ?>